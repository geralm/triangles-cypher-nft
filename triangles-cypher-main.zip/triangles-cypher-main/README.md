# triangles-cypher
Código en Python para codificar y decodificar texto en un abecedario con forma de triángulos
